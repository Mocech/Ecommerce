// static/js/mdb-init.js
import { Modal, Ripple, initMDB } from "mdb-ui-kit"; // Required for MDB modals

// Initialize the MDB components
initMDB({ Modal, Ripple });
